def go_to_login_page(page):
    page.goto("https://dev.paperlust.co/design-cascade/639/wedding-invitations--digital-printing--foil-of-dreams-invitations/")
